import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-extra-page',
  templateUrl: './about-extra-page.component.html',
  styleUrls: ['./about-extra-page.component.scss']
})
export class AboutExtraPageComponent implements OnInit {


  constructor() { }

  ngOnInit() {
  }

}
